// Example sports news data
